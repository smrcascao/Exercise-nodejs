
// var express = require('express')
 
// var app = express()
 
// app.get('/notes', function(req, res) {
	
//   res.json({notes: "This is your notebook. Edit this to start saving your notes!"})
// })
 
// app.listen(3001)

var express = require('express');
var app = express();

var bodyParser = require('body-parser');
var jsonfile = require('jsonfile');

app.listen(8080);

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({

	extended: true
}));

//carregar ficheiro json
var file = 'login.json'
var json=jsonfile.readFileSync(file);
console.dir(json);

//var config = require('./test.json');

app.get('/',function(req,res){

	res.end('server ok ;)');

});

app.get('/user',function(req,res){

	res.json([
		{name: 'Sergio',
		mail: "sergio@mail.pt" },
		{name: 'Joaquim',
				mail: "Joaquim@mail.pt" },
		{name: 'Paulo',
				mail: "Paulo@mail.pt" },
		{name: 'Marco',
			mail: "Marco@mail.pt" }
		]);


});

//http://127.0.0.1:5000/user/login?id=JP&pass=abchjkl
app.get('/login',function(req,res){

	var id= req.param('id');
	var pass= req.param('pass');

for (i = 0; i < json.length; i++) { 
   if(id==json[i].mail & pass ==json[i].password)
   			
			//res.end('O User '+json[i].mail+' exite a password é: '+json[i].password);   
			res.end(JSON.stringify(json[i]));   	
			
	else
		res.end('O user não está registado '+id);		
}
	
});

app.post('/user',function(req,res){

	res.end('/Cria um novo User');

});

app.put('/user:id',function(req,res){

	res.end('/Actualiza o user ID');

});